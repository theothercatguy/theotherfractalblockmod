SMODS.Joker{ --orc
    key = "orc",
    config = {
        extra = {
            odds = 10,
            ignore = 0
        }
    },
    loc_txt = {
        ['name'] = 'orc',
        ['text'] = {
            [1] = 'has a {C:green}1/10{} chance to make a {C:dark_edition}negative{} {C:spectral}troll{} when a {C:attention}cannoned{} card is destroyed.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 2,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 3,
    rarity = 1,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fractalb_mycustom_jokers"] = true },

    calculate = function(self, card, context)
        if context.remove_playing_cards  then
            if (function()
    for k, removed_card in ipairs(context.removed) do
        if SMODS.get_enhancements(removed_card)["m_fractalb_cannoned"] == true then
            return true
        end
    end
    return false
end)() then
                if SMODS.pseudorandom_probability(card, 'group_0_d5e2d774', 1, card.ability.extra.odds, 'j_fractalb_orc', false) then
              SMODS.calculate_effect({func = function()
            local created_joker = true
            G.E_MANAGER:add_event(Event({
                func = function()
                    local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_fractalb_troll' })
                    if joker_card then
                        joker_card:set_edition("e_negative", true)
                        
                    end
                    
                    return true
                end
            }))
            
            if created_joker then
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "LUCKY!!!!", colour = G.C.BLUE})
            end
            return true
        end}, card)
          end
            end
        end
    end
}
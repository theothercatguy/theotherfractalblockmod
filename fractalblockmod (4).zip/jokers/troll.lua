SMODS.Joker{ --troll
    key = "troll",
    config = {
        extra = {
        }
    },
    loc_txt = {
        ['name'] = 'troll',
        ['text'] = {
            [1] = 'adds a {C:attention}cannoned{} ace of {C:spades}Spades{} to your hand at the start of a round.'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 4,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 10,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fractalb_mycustom_jokers"] = true },

    calculate = function(self, card, context)
        if context.first_hand_drawn  then
                return {
                    func = function()
                local card_front = G.P_CARDS.S_A
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_fractalb_cannoned
                }, G.discard, true, false, nil, true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end,
                    message = "WELCOME"
                }
        end
    end
}
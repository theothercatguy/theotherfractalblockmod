SMODS.Enhancement {
    key = 'plasma',
    pos = { x = 1, y = 0 },
    config = {
        mult = -10,
        extra = {
            odds = 5
        }
    },
    loc_txt = {
        name = 'plasma',
        text = {
        [1] = 'has a {C:green}1 in 5{} chance to create a negative troll when scored.',
        [2] = '{C:red}-10 mult{}'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.main_scoring and context.cardarea == G.play then
            if SMODS.pseudorandom_probability(card, 'group_0_b86fd855', 1, card.ability.extra.odds, 'm_fractalb_plasma') then
                local created_joker = true
                G.E_MANAGER:add_event(Event({
                    func = function()
                        local joker_card = SMODS.add_card({ set = 'Joker', key = 'j_fractalb_troll' })
                        if joker_card then
                            joker_card:set_edition("e_negative", true)
                            
                        end
                        
                        return true
                    end
                }))
                card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "SPAWNED", colour = G.C.BLUE})
            end
        end
    end
}
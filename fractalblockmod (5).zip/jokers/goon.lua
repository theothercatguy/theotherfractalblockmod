SMODS.Joker{ --goon
    key = "goon",
    config = {
        extra = {
            mult = 20
        }
    },
    loc_txt = {
        ['name'] = 'goon',
        ['text'] = {
            [1] = 'spawns a holographic plasma ace of {C:diamonds}diamonds{} after hand is played.',
            [2] = 'plasma cards give{C:red} +20 Mult{}'
        },
        ['unlock'] = {
            [1] = 'Unlocked by default.'
        }
    },
    pos = {
        x = 1,
        y = 0
    },
    display_size = {
        w = 71 * 1, 
        h = 95 * 1
    },
    cost = 5,
    rarity = 2,
    blueprint_compat = true,
    eternal_compat = true,
    perishable_compat = true,
    unlocked = true,
    discovered = true,
    atlas = 'CustomJokers',
    pools = { ["fractalb_fractalb_jokers"] = true },

    calculate = function(self, card, context)
        if context.individual and context.cardarea == G.play  then
            if SMODS.get_enhancements(context.other_card)["m_fractalb_plasma"] == true then
                return {
                    mult = card.ability.extra.mult
                }
            end
        end
        if context.before and context.cardarea == G.jokers  then
                return {
                    func = function()
                local card_front = G.P_CARDS.D_A
                local new_card = create_playing_card({
                    front = card_front,
                    center = G.P_CENTERS.m_fractalb_plasma
                }, G.discard, true, false, nil, true)
            new_card:set_edition("e_holo", true)
                
                G.playing_card = (G.playing_card and G.playing_card + 1) or 1
                new_card.playing_card = G.playing_card
                table.insert(G.playing_cards, new_card)
                
                G.E_MANAGER:add_event(Event({
                    func = function()
                        G.hand:emplace(new_card)
                        new_card:start_materialize()
                        SMODS.calculate_context({ playing_card_added = true, cards = { new_card } })
                        return true
                    end
                }))
            end,
                    message = "Added Card to Hand!"
                }
        end
    end
}
SMODS.Enhancement {
    key = 'cannoned',
    pos = { x = 0, y = 0 },
    config = {
        extra = {
            timesplayed = 0,
            retrigger_times_min = 5,
            retrigger_times_max = 7,
            odds = 2,
            mult = 2,
            chips = 10
        }
    },
    loc_txt = {
        name = 'cannoned',
        text = {
        [1] = 'retrigger this card {C:attention}5-7{} times.',
        [2] = '{C:green}1/2{} chance for {C:red}2 mult{}. {C:green}1/2{} chance for {C:blue}10 chips{}.',
        [3] = 'can only be triggered {C:attention}10 times.',
        [4] = '{} gains {C:attention}1 time{} if held in hand.'
    }
    },
    atlas = 'CustomEnhancements',
    any_suit = false,
    shatters = true,
    replace_base_card = false,
    no_rank = false,
    no_suit = false,
    always_scores = false,
    unlocked = true,
    discovered = true,
    no_collection = false,
    weight = 5,
    calculate = function(self, card, context)
        if context.destroy_card and context.cardarea == G.play and context.destroy_card == card and card.should_destroy then
            return { remove = true }
        end
        if context.repetition and card.should_retrigger then
            return { repetitions = card.ability.extra.retrigger_times }
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_retrigger = false
            if (card.ability.extra.timesplayed or 0) ~= 10 then
                card.should_retrigger = true
            card.ability.extra.retrigger_times = pseudorandom('retrigger_times_a97bb76a', card.ability.extra.retrigger_times_min, card.ability.extra.retrigger_times_max)
            card.ability.extra.timesplayed = (card.ability.extra.timesplayed) + 1
            if SMODS.pseudorandom_probability(card, 'group_0_5c4a601f', 1, card.ability.extra.odds, 'm_fractalb_cannoned') then
                SMODS.calculate_effect({mult = card.ability.extra.mult}, card)
            end
            if SMODS.pseudorandom_probability(card, 'group_1_a35f01d0', 1, card.ability.extra.odds, 'm_fractalb_cannoned') then
                SMODS.calculate_effect({chips = card.ability.extra.chips}, card)
            end
            end
        end
        if context.main_scoring and context.cardarea == G.play then
            card.should_destroy = false
            if (card.ability.extra.timesplayed or 0) == 10 then
                card.should_destroy = true
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "OUT OF AMMO", colour = G.C.RED})
            end
        end
        if context.cardarea == G.hand and context.main_scoring then
            card.ability.extra.timesplayed = math.max(0, (card.ability.extra.timesplayed) - pseudorandom('timesplayed_f70a372f', 1, 3))
            card_eval_status_text(context.blueprint_card or card, 'extra', nil, nil, nil, {message = "RELAODING...", colour = G.C.RED})
        end
    end
}